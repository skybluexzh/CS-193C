// data for optional find location extension to maps assignment
// x and y coordinates are for map-xl.gif, you should scale them
// in your program based on the current map resolution

var locationArray = new Array(
		{names: ["Gates"], x: 1558, y: 1461},
		{names: ["MemChu","Memorial Church"], x: 1845, y: 1883},
		{names: ["Tresidder Union", "Tresidder"], x: 1804, y: 2225},		
		{names: ["Florence Moore Hall", "Florence Moore", "FloMo"], x: 1705, y: 2496},
		{names: ["Bookstore", "Book Store"], x: 2022, y: 2144},
		{names: ["MemAud", "Memorial Auditorium", "Memorial Hall"], x: 2262, y: 1600},
		{names: ["Green Library", "Green"], x: 2173, y: 1898},
		{names: ["Meyer Library", "Meyer"], x: 2157, y: 2026}			
	);
