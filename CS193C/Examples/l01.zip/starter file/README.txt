Here is a blank starter file to use for you HTML files.

Note that the starter-html.html file may display validation errors until you enter an actual title and an fill in the body.